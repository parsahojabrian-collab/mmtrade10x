import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

PKG = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('webview_r3a', PKG/'install.py')
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)

def sha(data): return hashlib.sha256(data).hexdigest()

CSS = (mod.OLD_BEGIN + ' */\n.step-dialog {display:grid}\n' + mod.OLD_END + '\n').encode()
HTML = b'''<!doctype html><link rel="stylesheet" href="/miniapp/p74/eplanet/styles.css?v=VPS_CUSTOM_VERSION"><script src="/miniapp/p74/eplanet/app.js?v=keep"></script>'''

class InstallerTests(unittest.TestCase):
 def setUp(self):
  self.temp = tempfile.TemporaryDirectory()
  self.addCleanup(self.temp.cleanup)
  b = Path(self.temp.name)
  repo = b/'repo'
  live = b/'live'
  self.paths = {
   'source_css': repo/'public/miniapp/p74/eplanet/styles.css',
   'live_css':live/'p74/eplanet/styles.css',
   'page_source':repo/'public/miniapp/p74/eplanet/index.html',
   'page_live':live/'p74/eplanet/index.html',
  }
  r2 = {'entries':{}}
  email = {'entries':{}}
  for key,path in self.paths.items():
   data = CSS if 'css' in key else HTML
   path.parent.mkdir(parents=True,exist_ok=True)
   path.write_bytes(data)
   (r2 if 'css' in key else email)['entries'][key] = {'path':str(path),'after':sha(data)}
  api=repo/'apps/api/src/index.ts'
  api.parent.mkdir(parents=True,exist_ok=True)
  api.write_text('unchanged API')
  email['entries']['api'] = {'path':str(api),'after':sha(api.read_bytes())}
  self.api = api
  for name,obj in [('r2.json',r2),('email.json',email)]:
   (b/name).write_text(json.dumps(obj))
  self.old = (mod.FILES,mod.R2_STATE,mod.EMAIL_STATE,mod.STATE)
  mod.FILES=self.paths
  mod.R2_STATE=b/'r2.json'
  mod.EMAIL_STATE=b/'email.json'
  mod.STATE=b/'webview_state.json'
  self.env=patch.dict(os.environ,{'MMTRADE_WEBVIEW_BACKUP_ROOT':str(b/'backups')})
  self.env.start()
  self.addCleanup(self.env.stop)
  self.addCleanup(self.reset)
 def reset(self):
  mod.FILES,mod.R2_STATE,mod.EMAIL_STATE,mod.STATE = self.old
 def test_replaces_old_custom_css_version_and_rolls_back_every_byte(self):
  originals={k:p.read_bytes() for k,p in self.paths.items()}
  before,after,_=mod.plan()
  for k in ('page_source','page_live'):
   self.assertIn(b'v=EPLANET_GLASS_WEBVIEW_R3A',after[k])
   self.assertIn(b'app.js?v=keep',after[k])
  self.assertIn(mod.NEW_BEGIN.encode(),after['live_css'])
  mod.install()
  mod.verify()
  self.assertEqual(self.api.read_text(),'unchanged API')
  mod.rollback()
  self.assertFalse(mod.STATE.exists())
  for k,p in self.paths.items():self.assertEqual(p.read_bytes(), originals[k])
 def test_html_with_old_original_version(self):
  out=mod.transform_html(b'<link rel="stylesheet" href="/miniapp/p74/eplanet/styles.css?v=EPLANET_FIX_R3">')
  self.assertIn(b'R3A',out)
 def test_html_with_other_attributes_and_query_is_preserved(self):
  inp=b"<link href='/miniapp/p74/eplanet/styles.css?token=x&v=R2&debug=y' rel='stylesheet' data-label='safe'>"
  out=mod.transform_html(inp)
  self.assertIn(b'token=x&v=EPLANET_GLASS_WEBVIEW_R3A&debug=y',out)
  self.assertIn(b"data-label='safe'",out)
 def test_html_without_query_version(self):
  out=mod.transform_html(b'<link rel="stylesheet" href="/miniapp/p74/eplanet/styles.css">')
  self.assertIn(b'?v=EPLANET_GLASS_WEBVIEW_R3A',out)
 def test_html_duplicate_links_rejected(self):
  tag=b'<link rel="stylesheet" href="/miniapp/p74/eplanet/styles.css?v=a">'
  with self.assertRaisesRegex(RuntimeError,'EPLANET_STYLESHEET_TAG_COUNT:2'):
   mod.transform_html(tag+tag)
 def test_does_not_match_unrelated_stylesheet(self):
  with self.assertRaisesRegex(RuntimeError,'EPLANET_STYLESHEET_TAG_COUNT:0'):
   mod.transform_html(b'<link rel="stylesheet" href="/miniapp/p74/other/styles.css?v=old">')
 def test_duplicate_version_parameter_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'DUPLICATE_CSS_VERSION_PARAMETER'):
   mod.transform_html(b'<link rel="stylesheet" href="styles.css?v=old&v=two">')
 def test_fail_closed_when_css_changed(self):
  self.paths['source_css'].write_bytes(b'unknown css')
  with self.assertRaisesRegex(RuntimeError,'PREVIOUS_STATE_HASH_MISMATCH'):
   mod.plan()
 def test_fail_closed_when_email_api_changed(self):
  self.api.write_text('unexpected API')
  with self.assertRaisesRegex(RuntimeError,'EMAIL_R3_NON_HTML_MODIFIED'):
   mod.plan()
 def test_fail_closed_source_live_differ(self):
  self.paths['page_live'].write_bytes(b'<link rel="stylesheet" href="styles.css?v=other">')
  with self.assertRaisesRegex(RuntimeError,'PREVIOUS_STATE_HASH_MISMATCH'):
   mod.plan()
 def test_already_versioned_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'CSS_ALREADY_AT_TARGET_VERSION'):
   mod.transform_html(b'<link rel="stylesheet" href="styles.css?v=EPLANET_GLASS_WEBVIEW_R3A">')

if __name__ == '__main__': unittest.main()
