#!/usr/bin/env python3
"""Safely switch ePlanet dialog from R2 Grid to R3 block layout and bust HTML stylesheet URL.

This package intentionally changes only Source+Live ePlanet CSS and HTML. It checks
previous R2/R3 install-state before editing, and preserves a full rollback snapshot.
"""
from __future__ import annotations
import hashlib, json, os, re, sys, tempfile
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=Path(os.environ.get('MMTRADE_REPO_ROOT','/root/miniapp10x'))
LIVE=Path(os.environ.get('MMTRADE_LIVE_ROOT','/srv/tenx-public/miniapp'))
R2_STATE=Path(os.environ.get('MMTRADE_GLASS_R2_STATE','/root/MMTRADE_EPLANET_MODAL_GLASS_COMPACT_R2/compact-glass-install-state.json'))
EMAIL_STATE=Path(os.environ.get('MMTRADE_EMAIL_R3_STATE','/root/MMTRADE_EPLANET_EMAIL_MATCH_VPS_R3/install-state.json'))
STATE=Path(os.environ.get('MMTRADE_WEBVIEW_PATCH_STATE',str(ROOT/'glass-webview-install-state.json')))
FILES={
 'source_css':SOURCE/'public/miniapp/p74/eplanet/styles.css',
 'live_css':LIVE/'p74/eplanet/styles.css',
 'page_source':SOURCE/'public/miniapp/p74/eplanet/index.html',
 'page_live':LIVE/'p74/eplanet/index.html',
}
OLD_BEGIN='/* MMTRADE_EPLANET_MODAL_GLASS_COMPACT_R2_BEGIN'
OLD_END='/* MMTRADE_EPLANET_MODAL_GLASS_COMPACT_R2_END */'
NEW_BEGIN='/* MMTRADE_EPLANET_GLASS_WEBVIEW_R3_BEGIN'
NEW_END='/* MMTRADE_EPLANET_GLASS_WEBVIEW_R3_END */'
NEW_VERSION='EPLANET_GLASS_WEBVIEW_R3A'
NEW_HREF='styles.css?v='+NEW_VERSION

def digest(data:bytes)->str:return hashlib.sha256(data).hexdigest()

def atomic(path:Path,data:bytes,mode:int)->None:
 fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.mm-eplanet-webview-')
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.chmod(tmp,mode)
  os.replace(tmp,path)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

def read_state(path:Path,label:str):
 if not path.is_file():raise RuntimeError(label+'_STATE_MISSING')
 return json.loads(path.read_text())

def verify_unmodified_email(state:dict):
 # HTML changes are intentionally managed by this install; all JS/API/admin files must match R3.
 for key,entry in state['entries'].items():
  if key in ('page_source','page_live'):continue
  p=Path(entry['path'])
  if not p.is_file() or digest(p.read_bytes())!=entry['after']:
   raise RuntimeError('EMAIL_R3_NON_HTML_MODIFIED:'+key)

def transform_css(raw:bytes,new_css:bytes)->bytes:
 s=raw.decode('utf-8'); n=new_css.decode('utf-8').rstrip('\n')
 if s.count(OLD_BEGIN)!=1 or s.count(OLD_END)!=1:raise RuntimeError('EXPECTED_R2_CSS_BLOCK_ONCE')
 if n.count(NEW_BEGIN)!=1 or n.count(NEW_END)!=1:raise RuntimeError('NEW_CSS_INVALID')
 if NEW_BEGIN in s or NEW_END in s:raise RuntimeError('WEBVIEW_PATCH_ALREADY_PRESENT')
 start=s.index(OLD_BEGIN);end=s.index(OLD_END,start)+len(OLD_END)
 return (s[:start]+n+s[end:]).encode('utf-8')

def transform_html(raw:bytes)->bytes:
 s=raw.decode('utf-8')
 # Locate the actual ePlanet stylesheet tag, whatever its current cache version.
 # Do not touch similarly named text elsewhere (scripts, descriptions, comments).
 valid_paths={'/miniapp/p74/eplanet/styles.css', 'styles.css', './styles.css'}
 tags=[]
 for link in re.finditer(r'<link\b[^>]*>',s,re.I):
  tag=link.group(0)
  if not re.search(r"""\brel\s*=\s*(['\"])stylesheet\1""",tag,re.I):
   continue
  href=re.search(r"""\bhref\s*=\s*(['\"])([^'\"]+)\1""",tag,re.I)
  if not href:continue
  from urllib.parse import urlsplit
  u=urlsplit(href.group(2))
  if u.scheme or u.netloc or u.path not in valid_paths:continue
  tags.append((link,href,u))
 if len(tags)!=1:raise RuntimeError('EPLANET_STYLESHEET_TAG_COUNT:'+str(len(tags)))
 link,href,u=tags[0]
 original=href.group(2)
 # Preserve the other query arguments and their original representation exactly.
 # The v parameter must be single-valued to avoid cache ambiguity.
 pieces=u.query.split('&') if u.query else []
 versions=[i for i,part in enumerate(pieces) if part.split('=',1)[0]=='v']
 if len(versions)>1:raise RuntimeError('DUPLICATE_CSS_VERSION_PARAMETER')
 if versions:
  pieces[versions[0]]='v='+NEW_VERSION
 else:
  pieces.append('v='+NEW_VERSION)
 query='&'.join(pieces)
 updated=u.path+'?'+query+('#'+u.fragment if u.fragment else '')
 if updated==original:raise RuntimeError('CSS_ALREADY_AT_TARGET_VERSION')
 a=link.start()+href.start(2)
 b=link.start()+href.end(2)
 return (s[:a]+updated+s[b:]).encode('utf-8')

def plan():
 if STATE.exists():raise RuntimeError('ALREADY_INSTALLED_USE_VERIFY_OR_ROLLBACK')
 r2=read_state(R2_STATE,'GLASS_R2')
 email=read_state(EMAIL_STATE,'EMAIL_R3')
 verify_unmodified_email(email)
 css_file=ROOT/'glass-webview-dialog.css'
 if not css_file.is_file():raise RuntimeError('PATCH_CSS_MISSING')
 new_css=css_file.read_bytes()
 old={};updates={};modes={}
 for label,path in FILES.items():
  if not path.is_file():raise RuntimeError('TARGET_MISSING:'+label)
  original=path.read_bytes();old[label]=original;modes[label]=path.stat().st_mode & 0o777
  prev=(r2 if 'css' in label else email)['entries'].get(label)
  if not prev or prev['path']!=str(path) or digest(original)!=prev['after']:
   raise RuntimeError('PREVIOUS_STATE_HASH_MISMATCH:'+label)
  updates[label]=transform_css(original,new_css) if 'css' in label else transform_html(original)
 if old['source_css']!=old['live_css'] or old['page_source']!=old['page_live']:
  raise RuntimeError('SOURCE_LIVE_DIFFERENT_ABORT')
 return old,updates,modes

def audit():
 old,updates,_=plan()
 print('AUDIT=PASS NO_WRITES=YES')
 print('CAUSES_ADDRESSED=CSS_VERSION_CACHE,WEBKIT_DIALOG_GRID,GLASS_COMPOSITOR')
 print('CSS_ONLY_PLUS_HTML_STYLESHEET_VERSION=YES')
 print('API_JS_WORKFLOW_DATABASE_REFERRAL=UNCHANGED')
 for k in FILES:print(f'{k} BEFORE={digest(old[k])[:12]} AFTER={digest(updates[k])[:12]}')
 return old,updates

def install():
 old,updates,modes=plan()
 stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 backup=Path(os.environ.get('MMTRADE_WEBVIEW_BACKUP_ROOT',str(ROOT/'backups')))/stamp
 backup.mkdir(parents=True,exist_ok=False)
 for label,data in old.items():(backup/(label+'.bak')).write_bytes(data)
 entries={k:{'path':str(FILES[k]),'before':digest(old[k]),'after':digest(updates[k]),'mode':modes[k]} for k in FILES}
 done=[]
 try:
  for label,path in FILES.items():
   atomic(path,updates[label],modes[label]);done.append(label)
  atomic(STATE,json.dumps({'backup':str(backup),'entries':entries},indent=2).encode(),0o600)
 except BaseException:
  for label in reversed(done):atomic(FILES[label],old[label],modes[label])
  raise
 print('INSTALL=PASS BACKUP='+str(backup))
 print('BUILD_REQUIRED=NO API_RESTART_REQUIRED=NO')

def verify():
 state=read_state(STATE,'WEBVIEW_R3')
 email=read_state(EMAIL_STATE,'EMAIL_R3')
 verify_unmodified_email(email)
 for label,entry in state['entries'].items():
  path=Path(entry['path'])
  if path!=FILES[label] or not path.is_file() or digest(path.read_bytes())!=entry['after']:
   raise RuntimeError('VERIFY_HASH_MISMATCH:'+label)
 for label in ('page_source','page_live'):
  # The cache URL can contain other query args; validate the actual stylesheet
  # instead of assuming the version is the first query argument.
  try: transform_html(FILES[label].read_bytes())
  except RuntimeError as error:
   if str(error) != 'CSS_ALREADY_AT_TARGET_VERSION':
    raise RuntimeError('VERSION_NOT_BUSTED:'+label+':'+str(error)) from error
  else:raise RuntimeError('VERSION_NOT_BUSTED:'+label)
 print('VERIFY=PASS SOURCE_LIVE_SYNC=YES')
 print('EMAIL_R3_NON_HTML=UNCHANGED; REFERRAL_CTA=UNCHANGED')
 print('NOTE=EMAIL_R3_VERIFY_WILL_FLAG_EXPECTED_HTML_CHANGE_UNTIL_ROLLBACK')

def rollback():
 verify();state=read_state(STATE,'WEBVIEW_R3')
 restores={}
 for label,entry in state['entries'].items():
  data=(Path(state['backup'])/(label+'.bak')).read_bytes()
  if digest(data)!=entry['before']:raise RuntimeError('BACKUP_HASH_MISMATCH:'+label)
  restores[label]=data
 for label,entry in state['entries'].items():atomic(FILES[label],restores[label],entry['mode'])
 STATE.unlink()
 print('ROLLBACK=PASS R2_CSS_AND_R3_HTML_RESTORED=YES')

if __name__=='__main__':
 try:
  name=sys.argv[1] if len(sys.argv)>1 else 'audit'
  if name not in ('audit','install','verify','rollback'):raise RuntimeError('UNKNOWN_COMMAND:'+name)
  {'audit':audit,'install':install,'verify':verify,'rollback':rollback}[name]()
 except Exception as ex:
  print('ERROR='+str(ex),file=sys.stderr);sys.exit(1)
