# MMTRADE ePlanet — Glass WebView R3A (اصلاح خطای CSS_HREF_NOT_UNIQUE:0)

## علت
نسخه R3 به اشتباه آدرس CSS را با رشته ثابت `styles.css?v=EPLANET_FIX_R3` جست‌وجو می‌کرد. اگر نسخه کش در HTML زنده متفاوت باشد، Audit با `CSS_HREF_NOT_UNIQUE:0` متوقف می‌شود. این خطا نشان‌دهنده مشکل در *تشخیص لینک CSS توسط نصب‌کننده* است، نه ایراد مستقیم در API و نه لزوماً خرابی CSS.

## اصلاح R3A
- شناسایی دقیق و یکتای `<link rel="stylesheet" href=".../eplanet/styles.css?...">` بدون وابستگی به مقدار فعلی پارامتر `v`.
- فقط مقدار `v` به `EPLANET_GLASS_WEBVIEW_R3A` تغییر می‌کند. سایر پارامترهای URL، اسکریپت‌ها، فرم و HTML دست‌نخورده باقی می‌مانند.
- جایگزینی کامل بلوک CSS Glass Compact R2 با CSS شیشه‌ای WebView R3 (چیدمان Block).
- کنترل هش دقیق فایل‌های نصب‌شده نسخه Email Match R3 و Compact Glass R2، اجبار هماهنگی Source و Live، بکاپ و Rollback اتمیک.
- بدون تغییر در API، استعلام IB، وضعیت کاربران، دیتابیس، لینک رفرال یا Worker.

## نصب — بعد از قرار دادن فایل ZIP در `/root`

```bash
cd /root && unzip -oq MMTRADE_EPLANET_GLASS_WEBVIEW_R3A.zip
python3 -m unittest discover -s /root/MMTRADE_EPLANET_GLASS_WEBVIEW_R3A/tests -v
python3 /root/MMTRADE_EPLANET_GLASS_WEBVIEW_R3A/install.py audit
```

**فقط اگر Audit=PASS بود**:

```bash
python3 /root/MMTRADE_EPLANET_GLASS_WEBVIEW_R3A/install.py install && python3 /root/MMTRADE_EPLANET_GLASS_WEBVIEW_R3A/install.py verify
```

صفحه مینی‌اپ تلگرام را کاملاً ببندید و دوباره باز کنید؛ برای مشاهده نسخه CSS روی سرور:

```bash
curl -fsS https://mmtrade10x.ir/miniapp/p74/eplanet/index.html | grep -o 'EPLANET_GLASS_WEBVIEW_R3A'
```

## Rollback (تنها هنگام نیاز)

```bash
python3 /root/MMTRADE_EPLANET_GLASS_WEBVIEW_R3A/install.py rollback
```

نصب/بازگشت به Build یا Restart API نیاز ندارد. نصب‌کننده قدیمی Email Match R3 بعد از نصب به دلیل تغییر عمدی HTML (نسخه CSS) ممکن است Verify را مردود اعلام کند؛ برای بررسی پچ UI از Verify همین نسخه R3A استفاده کنید.

## محدودیت
اجرای تست‌ها با فایل‌های شبیه‌سازی‌شده انجام شده و نسخه نصب‌شده هنوز روی دستگاه واقعی iOS دیده نشده است. Audit از فایل‌های واقعی سرور حفاظت می‌کند. موفقیت Verify به تنهایی درستی رندر WebView را اثبات نمی‌کند.
